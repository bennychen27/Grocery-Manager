import java.util.ArrayList;

/**
 *
 * Generic GroceryOrder class is used to create an arraylist of GroceryItems taking type parameter T
 * 
 * @author Benny Chen
 * @section CSS 143B
 * @version 12-3-18
 *
 */
public class GroceryOrder<T> extends ArrayList<GroceryItem>{

	
	
}
